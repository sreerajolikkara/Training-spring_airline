package com.riya.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="flights")
public class Flight {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="FlightNo")
	private int flightno;
	
	@Column(name="FlightName")
	private String flightName;
	
	@Column(name="Price")
	private String price;
	
	
	public Flight() {
		
	}

	public int getId() {
		return flightno;
	}

	public void setId(int flightno) {
		this.flightno = flightno;
	}

	public String getFirstName() {
		return flightName;
	}

	public void setFirstName(String flightName) {
		this.flightName = flightName;
	}

	public String getLastName() {
		return price;
	}

	public void setLastName(String price) {
		this.price = price;
	}

		
	@Override
	public String toString() {
		return "Customer [FlightNo=" + flightno + ", FlightName=" + flightName + ", Price=" + price +  "]";
	}
		
}





