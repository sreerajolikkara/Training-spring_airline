package com.riya.entity;

public class FlightDataModel {


		private int flightno;
		

		private String flightName;
		

		private String price;


		public FlightDataModel(int flightno, String flightName, String price) {
			super();
			this.flightno = flightno;
			this.flightName = flightName;
			this.price = price;
		}
		
		
		
}
