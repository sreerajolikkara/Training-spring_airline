package com.riya.entity;

public class FlightModel {

	private String name;
	private int price;
	private String flightdeparture;

	
	public String getFlightdeparture() {
		return flightdeparture;
	}

	public void setFlightdeparture(String flightdeparture) {
		this.flightdeparture = flightdeparture;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public FlightModel() {
		
	}

	public FlightModel(String name) {
		
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
