package com.riya.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.riya.entity.FlightModel;

@Controller
public class DemoAppController {

	@GetMapping("/")
	public String showHomePage(@ModelAttribute(name = "myFlight")FlightModel flightModel) {
		return "custom-login";
	}
	
}
