package com.riya.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.riya.entity.Flight;
import com.riya.entity.FlightModel;

@Controller
public class LoginController {
	@GetMapping("showMyLoginPage")
	public String showMyLoginPage() {
		return "custom-login";
	}


public List<String> getConnection() {
		
		List<String> names = new ArrayList<String>();
		List<Flight> flightDetails = new ArrayList<Flight>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/flightlist","root","root");
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery("select * from flights");
			while(rs.next()) {
				names.add(rs.getString("FlightName"));
				flightDetails.add(new Flight(rs.getInt("FlightNo"),rs.getString("flightName")))
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return names;
		
	}
	@GetMapping("home")
	public String showMyLoginP(Model model) {
		List<String> names = getConnection();
		System.out.println(names);
		FlightModel flightModel = new FlightModel();
		flightModel.setName(names.get(0));
		model.addAttribute("myFlight",flightModel);
		return "home";
	}

	@GetMapping("/access-denied")
	public String showAccessDenied() {
		return "access-denied";
	}
}

